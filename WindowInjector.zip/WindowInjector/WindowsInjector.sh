#/bin/bash

bash src/banner.sh
